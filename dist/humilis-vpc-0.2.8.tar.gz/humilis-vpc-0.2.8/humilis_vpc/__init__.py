"""Humilis plug-in to deploy VPC and several subnets."""


__version__ = "0.2.8"
__author__ = "German Gomez-Herrero"
